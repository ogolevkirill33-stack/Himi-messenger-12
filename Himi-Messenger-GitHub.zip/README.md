# 💬 Himi Messenger

> Мессенджер нового поколения с 15,000+ подарками, Himi Coins, Premium и системой ключей.

## 🚀 Сборка APK через GitHub Actions

### Шаг 1 — Создай репозиторий
1. Зайди на [github.com/new](https://github.com/new)
2. Назови репозиторий: `Himi-Messenger`
3. Выбери **Public**
4. НЕ добавляй README (он уже есть)
5. Нажми **Create repository**

### Шаг 2 — Загрузи файлы
**Вариант A (через браузер):**
1. В репозитории нажми **uploading an existing file**
2. Перетащи все файлы из папки проекта
3. Нажми **Commit changes**

**Вариант B (через Git):**
```bash
git init
git add .
git commit -m "Initial commit"
git branch -M main
git remote add origin https://github.com/ТВО_НИК/Himi-Messenger.git
git push -u origin main
```

### Шаг 3 — Ждём сборку
1. Открой вкладку **Actions** в репозитории
2. Увидишь workflow **"Build Himi APK"** — он запустится автоматически
3. Подожди ~5-10 минут

### Шаг 4 — Скачай APK
1. В **Actions** кликни на завершённый workflow
2. Внизу страницы найди раздел **Artifacts**
3. Скачай **Himi-Messenger-APK**
4. Распакуй ZIP → установи `app-debug.apk` на телефон

---

## ❌ Если workflow падает — решения

### Ошибка: `Command not found: npx cap`
```yaml
# Уже исправлено в build.yml — используем npx
```

### Ошибка: `SDK licenses not accepted`
```yaml
# Уже добавлена строка: yes | sdkmanager --licenses || true
```

### Ошибка: `Java version`
```yaml
# Используем java-version: '17' и distribution: 'temurin'
```

### Ошибка: `Gradle build failed`
Проверь что файл `capacitor.config.json` есть в корне репозитория.

### Ошибка: `No files found at path`
Убедись что все файлы загружены:
```
Himi-Messenger/
├── .github/
│   └── workflows/
│       └── build.yml      ← ОБЯЗАТЕЛЬНО
├── www/
│   ├── index.html
│   ├── css/
│   │   └── app.css
│   └── js/
│       ├── data.js
│       ├── gifts.js
│       └── app.js
├── package.json            ← ОБЯЗАТЕЛЬНО
└── capacitor.config.json   ← ОБЯЗАТЕЛЬНО
```

---

## ⭐ Ключ для разблокировки

Ключ активации:
```
Himigyter1202040912050505
```

**После ввода ключа открывается:**
- 🎁 **Бесконечные подарки** — дари ЛЮБЫЕ подарки БЕСПЛАТНО
- ⭐ **Добавить звёзды** — введи любое число (хоть 999,999,999)
- 💎 **Всё и сразу** — 99,999 звёзд + монет + Premium

**Где вводить:** Профиль → Ввести ключ

---

## 📦 Что внутри

| Функция | Описание |
|---------|----------|
| 💬 Чаты | Ответы, реакции, голосовые, закрепление |
| 🎁 Подарки | 15,000+ уникальных подарков с карточками |
| 🛍️ Himi Store | Магазин с категориями и фильтрами |
| ⭐ Himi Coins | Внутренняя валюта, пополнение |
| 👑 Himi Premium | Дополнительные возможности |
| 📖 Истории | Stories на 24 часа |
| 🎮 Himi Games | 6 мини-игр |
| 🎨 Темы | 6 тёмных тем оформления |
| 🔑 Ключ | Разблокировка привилегий |

---

## 🛠️ Локальный запуск (для разработки)

```bash
npm install
npx cap init "Himi" "app.himi.messenger" --web-dir www
npx cap add android
npx cap sync android
# Открой Android Studio → android/
# Run → Run 'app'
```

---

*Himi Messenger © 2024*
