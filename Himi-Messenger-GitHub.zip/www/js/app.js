// ═══════════════════════════════════════════════════
// HIMI MESSENGER — MAIN APP
// ═══════════════════════════════════════════════════
const S = {
  user:{name:'Пользователь',handle:'@himi_user',av:'🙂'},
  coins:2500, stars:0, premium:false,
  currentChat:null, replyTo:null, rxnTarget:null,
  pinCode:'', currentTab:'chats',
  unlockedGifts:[], // after key — unlimited gifts
  adminUnlocked:false,
};
let typingTimer=null, emojiOpen=false;

// ── PAGE NAVIGATION ──
function go(pgId){
  document.querySelectorAll('.pg').forEach(p=>{p.classList.add('hidden');p.classList.remove('active');});
  const t=document.getElementById(pgId);
  if(t){t.classList.remove('hidden');t.classList.add('active');}
}

function toggleTheme(){
  const c=document.documentElement.getAttribute('data-theme');
  document.documentElement.setAttribute('data-theme',c==='light'?'dark':'light');
}

// ── PARTICLES ──
function makeParticles(containerId){
  const c=document.getElementById(containerId);
  if(!c)return;
  for(let i=0;i<18;i++){
    const d=document.createElement('div');
    d.style.cssText=`position:absolute;width:${4+Math.random()*8}px;height:${4+Math.random()*8}px;border-radius:50%;background:rgba(79,195,247,${0.2+Math.random()*0.4});left:${Math.random()*100}%;top:${Math.random()*100}%;animation:bfloat ${5+Math.random()*8}s ease-in-out ${-Math.random()*8}s infinite;`;
    c.appendChild(d);
  }
}

// ── REGISTER FLOW ──
let pinVal='';
function nextStep(n){
  document.querySelectorAll('.auth-step').forEach(s=>s.classList.add('hidden'));
  const el=document.getElementById('rs'+n);
  if(el)el.classList.remove('hidden');
  if(n===3 && document.getElementById('inpName')) document.getElementById('inpName').focus();
}
function codeNext(el){
  if(el.value.length===1){
    const ns=el.nextElementSibling;
    if(ns)ns.focus();
  }
}
function pin(n){
  if(pinVal.length>=5)return;
  pinVal+=n;
  for(let i=0;i<5;i++){
    const d=document.getElementById('pd'+i);
    if(d)d.classList.toggle('on',i<pinVal.length);
  }
}
function pinDel(){
  pinVal=pinVal.slice(0,-1);
  for(let i=0;i<5;i++){
    const d=document.getElementById('pd'+i);
    if(d)d.classList.toggle('on',i<pinVal.length);
  }
}
function pinOK(){
  if(pinVal.length<4){toast('⚠️','Короткий пароль','Введите минимум 4 цифры');return;}
  if(document.getElementById('inpName')){
    S.user.name=document.getElementById('inpName').value||'Пользователь';
    S.user.handle='@'+(document.getElementById('inpUser').value||'himi_user').replace('@','');
  }
  S.user.av=document.getElementById('selAv')?.textContent||'🙂';
  go('pgApp');
  initApp();
}
function doLogin(){
  go('pgApp');
  initApp();
}
function showAvatarPicker(){
  const modal=document.getElementById('avModal');
  const grid=document.getElementById('avGrid');
  grid.innerHTML=AVATARS.map(a=>`<div class="av-opt" onclick="pickAv('${a}')">${a}</div>`).join('');
  modal.classList.remove('hidden');
}
function pickAv(a){
  document.getElementById('selAv').textContent=a;
  S.user.av=a;
  closeAvModal();
}
function closeAvModal(){document.getElementById('avModal').classList.add('hidden');}

// ── APP INIT ──
function initApp(){
  makeParticles('splashParts');
  switchTab('chats');
  setTimeout(()=>toast('💬','Himi Messenger','Добро пожаловать, '+S.user.name+'!'),600);
  setTimeout(()=>toast('🔥','Himi Store','Открыт магазин подарков!'),3500);
}

// ── TABS ──
function switchTab(tab){
  S.currentTab=tab;
  const tabs=['chats','contacts','profile','settings'];
  tabs.forEach(t=>{
    document.getElementById('bn'+cap(t))?.classList.toggle('active',t===tab);
  });
  const content=document.getElementById('appContent');
  if(tab==='chats') content.innerHTML=renderChatsTab();
  else if(tab==='contacts') content.innerHTML=renderContactsTab();
  else if(tab==='profile') content.innerHTML=renderProfileTab();
  else if(tab==='settings') content.innerHTML=renderSettingsTab();
}
function cap(s){return s.charAt(0).toUpperCase()+s.slice(1);}

// ── CHATS TAB ──
function renderChatsTab(){
  const stories=STORIES_D.map(s=>`
    <div class="stry-item" onclick="openStory(${s.id})">
      <div class="stry-ring ${s.viewed?'viewed':''}"><div class="stry-inner">${s.av}</div></div>
      <div class="stry-lbl">${s.name}</div>
    </div>`).join('');
  const chatItems=CHATS_D.map((c,i)=>`
    <div class="ci anim-fade" style="animation-delay:${i*0.03}s" onclick="openChat(${c.id})">
      <div class="ci-av" style="background:${chatBg(c.id)}">
        ${c.av}${c.status==='online'?'<div class="ci-online"></div>':''}
      </div>
      <div class="ci-info">
        <div class="ci-top">
          <div class="ci-name">${c.name}${c.premium?'<span style="font-size:10px;background:var(--gold);color:#000;border-radius:5px;padding:1px 5px;margin-left:5px;font-weight:900">⭐</span>':''}${c.isBot?'<span style="font-size:10px;background:var(--acc);color:#000;border-radius:5px;padding:1px 5px;margin-left:5px;font-weight:900">🤖</span>':''}</div>
          <div class="ci-time">${c.time}</div>
        </div>
        <div class="ci-bot">
          <div class="ci-prev">${c.prev}</div>
          ${c.unread?`<div class="ci-badge">${c.unread}</div>`:''}
        </div>
      </div>
    </div>`).join('');
  return `
    <div class="tab-view">
      <div class="tab-hdr">
        <h2>Чаты</h2>
        <div class="tab-hdr-btns">
          <button class="ihbtn">+</button>
          <button class="ihbtn">📡</button>
        </div>
      </div>
      <div class="ftabs">
        <button class="ftab on">Все</button>
        <button class="ftab">Личное</button>
        <button class="ftab">Каналы</button>
        <button class="ftab">Боты</button>
      </div>
      <div class="sbar">
        <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="11" cy="11" r="8"/><path d="m21 21-4.35-4.35"/></svg>
        <input placeholder="Поиск" oninput="filterCI(this.value)">
      </div>
      <div style="display:flex;gap:8px;padding:8px 16px;overflow-x:auto;scrollbar-width:none;border-bottom:1px solid var(--bdr)">
        <div style="display:flex;flex-direction:column;align-items:center;gap:5px;flex-shrink:0;cursor:pointer" onclick="toast('📸','История','Добавьте фото!')">
          <button class="stry-add-btn">+</button>
          <div class="stry-lbl">Добавить</div>
        </div>
        ${stories}
      </div>
      <div id="chatListEl">${chatItems}</div>
    </div>`;
}
function chatBg(id){const c=['#1a3a5c','#1a2820','#3a1a2c','#1a2840','#2a1a3a','#3a2a1a','#1a3a3a','#2a3a1a','#3a1a1a','#1a1a3a'][id%10];return c;}
function filterCI(q){
  const el=document.getElementById('chatListEl');
  if(!el)return;
  const filtered=CHATS_D.filter(c=>!q||c.name.toLowerCase().includes(q.toLowerCase()));
  el.innerHTML=filtered.map((c,i)=>`
    <div class="ci" style="animation-delay:${i*0.02}s" onclick="openChat(${c.id})">
      <div class="ci-av">${c.av}${c.status==='online'?'<div class="ci-online"></div>':''}</div>
      <div class="ci-info">
        <div class="ci-top"><div class="ci-name">${c.name}</div><div class="ci-time">${c.time}</div></div>
        <div class="ci-bot"><div class="ci-prev">${c.prev}</div>${c.unread?`<div class="ci-badge">${c.unread}</div>`:''}</div>
      </div>
    </div>`).join('');
}

// ── CONTACTS TAB ──
function renderContactsTab(){
  const items=CONTACTS_D.map(c=>`
    <div class="cont-item" onclick="openChat(${c.id})">
      <div class="ci-av" style="background:${chatBg(c.id)}">${c.av}${c.status==='online'?'<div class="ci-online"></div>':''}</div>
      <div class="ci-info">
        <div class="ci-name">${c.name}${c.premium?'<span style="font-size:10px;background:var(--gold);color:#000;border-radius:5px;padding:1px 5px;margin-left:5px;font-weight:900">⭐</span>':''}</div>
        <div style="font-size:12px;color:var(--txt2)">${c.handle}</div>
      </div>
    </div>`).join('');
  return `<div class="tab-view"><div class="tab-hdr"><h2>Люди</h2></div>
    <div class="sbar"><svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="11" cy="11" r="8"/><path d="m21 21-4.35-4.35"/></svg><input placeholder="Поиск людей"></div>
    ${items}</div>`;
}

// ── PROFILE TAB ──
function renderProfileTab(){
  const myGifts=S.unlockedGifts.slice(0,8);
  const giftShow=myGifts.length?myGifts.map(g=>`
    <div class="gshow-item" onclick="showGiftCard(${g.id})">
      ${g.em}<div class="gsi-crown">👑</div>
    </div>`).join(''):'<div style="color:var(--txt3);font-size:13px;padding:10px">Нет подарков</div>';
  return `<div class="tab-view">
    <div class="prof-banner">
      <div class="prof-medal">
        <div class="medal-ring"></div>
        <div class="prof-av-inner">${S.user.av}</div>
      </div>
      <div class="prof-name">${S.user.name} ${S.premium?'⭐':''}</div>
      <div class="prof-handle">${S.user.handle}</div>
      <div class="prof-status-row">
        <div class="sdot" style="background:var(--green)"></div>
        <span style="font-size:13px">в сети</span>
      </div>
      <div style="display:flex;gap:24px;margin-top:8px">
        <div style="text-align:center"><div style="font-size:22px;font-weight:900;color:var(--acc)">${S.stars}</div><div style="font-size:11px;color:var(--txt2)">⭐ Звёзды</div></div>
        <div style="text-align:center"><div style="font-size:22px;font-weight:900;color:var(--gold)">${S.coins}</div><div style="font-size:11px;color:var(--txt2)">🪙 Монеты</div></div>
        <div style="text-align:center"><div style="font-size:22px;font-weight:900;color:var(--prem)">${S.premium?'✓':'—'}</div><div style="font-size:11px;color:var(--txt2)">👑 Premium</div></div>
      </div>
      <div class="prof-acts">
        <button class="btn-ghost" style="font-size:14px" onclick="openCoins()">🪙 Монеты</button>
        <button class="btn-main" style="font-size:14px" onclick="openPremium()">👑 Premium</button>
      </div>
    </div>
    <div class="gifts-sect">
      <h3>Подарки</h3>
      <div class="gifts-show">${giftShow}</div>
    </div>
    <div style="height:8px;background:var(--bg)"></div>
    <div class="sett-sect">
      <div class="sett-row" onclick="openKeyPanel()"><div class="si" style="background:linear-gradient(135deg,var(--gold),#ff8f00)">🔑</div><div class="si-info"><div class="si-title">Ввести ключ</div><div class="si-sub">Звёзды и неограниченные подарки</div></div><div class="si-arr">›</div></div>
      <div class="sett-row" onclick="openStore()"><div class="si" style="background:linear-gradient(135deg,var(--gold),#e65100)">🛍️</div><div class="si-info"><div class="si-title">Himi Store</div><div class="si-sub">15,000+ подарков</div></div><div class="si-arr">›</div></div>
      <div class="sett-row" onclick="openGames()"><div class="si" style="background:linear-gradient(135deg,#1565c0,#0d47a1)">🎮</div><div class="si-info"><div class="si-title">Himi Games</div><div class="si-sub">Мини-игры</div></div><div class="si-arr">›</div></div>
    </div>
  </div>`;
}

// ── SETTINGS TAB ──
function renderSettingsTab(){
  return `<div class="tab-view">
    <div class="tab-hdr"><h2>Настройки</h2></div>
    <div class="sett-sect">
      <div class="sett-head">АККАУНТ</div>
      <div class="sett-row" onclick="openPremium()"><div class="si" style="background:linear-gradient(135deg,#7b1fa2,#e91e63)">👑</div><div class="si-info"><div class="si-title">Himi Premium</div><div class="si-sub">${S.premium?'Активна':'Получите больше'}</div></div><div class="si-arr">›</div></div>
      <div class="sett-row" onclick="openCoins()"><div class="si" style="background:linear-gradient(135deg,var(--gold),#ff8f00)">🪙</div><div class="si-info"><div class="si-title">Himi Coins</div><div class="si-sub">${S.coins} монет</div></div><div class="si-arr">›</div></div>
      <div class="sett-row" onclick="openKeyPanel()"><div class="si" style="background:linear-gradient(135deg,var(--gold),var(--acc))">🔑</div><div class="si-info"><div class="si-title">Ввести ключ</div><div class="si-sub">${S.adminUnlocked?'Разблокировано ✅':'Активировать привилегии'}</div></div><div class="si-arr">›</div></div>
    </div>
    <div style="height:8px;background:var(--bg)"></div>
    <div class="sett-sect">
      <div class="sett-head">КАСТОМИЗАЦИЯ</div>
      <div class="sett-row" onclick="openThemes()"><div class="si" style="background:linear-gradient(135deg,#e91e63,#9c27b0)">🎨</div><div class="si-info"><div class="si-title">Темы оформления</div><div class="si-sub">Тёмная, светлая, цветная</div></div><div class="si-arr">›</div></div>
      <div class="sett-row"><div class="si" style="background:var(--bg4)">🖼️</div><div class="si-info"><div class="si-title">Фон чата</div><div class="si-sub">Анимированные фоны</div></div><div class="si-arr">›</div></div>
    </div>
    <div style="height:8px;background:var(--bg)"></div>
    <div class="sett-sect">
      <div class="sett-head">ПРИВАТНОСТЬ</div>
      <div class="sett-row"><div class="si" style="background:var(--bg4)">👁️</div><div class="si-info"><div class="si-title">Скрыть время посещения</div></div><button class="tog" onclick="this.classList.toggle('on')"></button></div>
      <div class="sett-row"><div class="si" style="background:var(--bg4)">✓</div><div class="si-info"><div class="si-title">Скрыть прочтение</div></div><button class="tog on" onclick="this.classList.toggle('on')"></button></div>
      <div class="sett-row"><div class="si" style="background:var(--bg4)">🔐</div><div class="si-info"><div class="si-title">Двухэтапная защита</div></div><button class="tog" onclick="this.classList.toggle('on')"></button></div>
      <div class="sett-row"><div class="si" style="background:var(--bg4)">🔔</div><div class="si-info"><div class="si-title">Уведомления</div></div><button class="tog on" onclick="this.classList.toggle('on')"></button></div>
    </div>
  </div>`;
}

// ── OPEN CHAT ──
function openChat(id){
  S.currentChat=id;
  const chat=CHATS_D.find(c=>c.id===id);
  if(!chat)return;
  chat.unread=0;
  const pg=document.getElementById('pgChat');
  pg.classList.remove('hidden');pg.classList.add('active');
  const statusTx={online:'в сети',offline:'не в сети',away:'отошёл',bot:'бот'};
  document.getElementById('chatHdr').innerHTML=`
    <button class="topbar-back" onclick="closeChat()">‹</button>
    <div class="chdr-av">${chat.av}</div>
    <div class="chdr-info" onclick="openChatProfile(${id})">
      <div class="chdr-name">${chat.name}</div>
      <div class="chdr-status">${statusTx[chat.status]||''}</div>
    </div>
    <div class="chdr-acts">
      <button class="hbtn" onclick="toast('📞','Звонок','Соединение...')">📞</button>
      <button class="hbtn" onclick="openGiftSend(${id})">🎁</button>
      <button class="hbtn" onclick="chatMenu(${id})">⋯</button>
    </div>`;
  if(id===1||id===5){
    const pb=document.getElementById('pinnedStrip');
    pb.classList.remove('hidden');
    document.getElementById('pinText').textContent=id===1?'Premium скидка 50% до конца месяца!':'Встречаемся в субботу в 15:00 🎉';
  } else {
    document.getElementById('pinnedStrip').classList.add('hidden');
  }
  renderMsgs(id);
  renderInput();
  if(id===1||id===3||id===5) setTimeout(showTypingIndicator,2000);
}
function closeChat(){
  document.getElementById('pgChat').classList.add('hidden');
  document.getElementById('pgChat').classList.remove('active');
  if(S.currentTab==='chats') switchTab('chats');
}
function closePinned(){document.getElementById('pinnedStrip').classList.add('hidden');}

// ── MESSAGES ──
function renderMsgs(chatId){
  const area=document.getElementById('msgsArea');
  const msgs=MSGS_D[chatId]||[];
  let html=`<div class="dchip"><span>Сегодня</span></div>`;
  msgs.forEach(m=>{html+=renderMsg(m,chatId);});
  area.innerHTML=html;
  area.scrollTop=area.scrollHeight;
  area.querySelectorAll('.bbl').forEach(el=>{
    el.addEventListener('contextmenu',e=>{e.preventDefault();showCtx(e,el);});
    let t;
    el.addEventListener('touchstart',()=>{t=setTimeout(()=>showCtx(null,el),500);},{passive:true});
    el.addEventListener('touchend',()=>clearTimeout(t));
    el.addEventListener('dblclick',e=>showRxnPicker(e,el));
  });
}
function renderMsg(m,chatId){
  const dir=m.out?'out':'in';
  let body='';
  if(m.type==='voice'){
    const bars=Array.from({length:26},()=>`<div class="wvb" style="height:${8+Math.random()*20}px"></div>`).join('');
    body=`<div class="vbbl"><button class="pbtn" onclick="playVoice(this)">▶</button><div class="wvform">${bars}</div><span class="vdur">${m.dur}</span></div>`;
  } else {
    body=`<div style="white-space:pre-wrap">${m.txt}</div>`;
  }
  const rxns=m.rxns?Object.entries(m.rxns).map(([e,c])=>`<div class="rxn-bbl" onclick="addRxn('${e}',${m.id},${chatId})">${e}<span>${c}</span></div>`).join(''):'';
  return `<div class="mw ${dir}" data-id="${m.id}">
    ${m.sender?`<div class="msender">${m.sender}</div>`:''}
    <div class="bbl ${dir}" data-mid="${m.id}" data-cid="${chatId}">
      ${m.replyTo?`<div class="rply-in"><strong>↩ ${m.replyTo.nm}</strong>${m.replyTo.tx}</div>`:''}
      ${body}
      <div class="mmeta"><span>${m.time}</span>${m.out?`<span class="mstatus">${m.status||'✓'}</span>`:''}</div>
    </div>
    ${rxns?`<div class="rxns">${rxns}</div>`:''}
  </div>`;
}
function addMsg(txt,chatId){
  if(!MSGS_D[chatId])MSGS_D[chatId]=[];
  const msgs=MSGS_D[chatId];
  const id=msgs.length+1;
  const m={id,txt,out:true,time:now(),status:'✓',replyTo:S.replyTo?{nm:S.replyTo.nm,tx:S.replyTo.tx}:null};
  msgs.push(m);
  S.replyTo=null;
  const rb=document.getElementById('rplyBarEl');
  if(rb)rb.remove();
  const area=document.getElementById('msgsArea');
  const wrap=document.createElement('div');
  wrap.innerHTML=renderMsg(m,chatId);
  area.appendChild(wrap.firstElementChild);
  area.scrollTop=area.scrollHeight;
  const chat=CHATS_D.find(c=>c.id===chatId);
  if(chat){chat.prev=txt;chat.time='сейчас';}
  setTimeout(()=>simReply(chatId),1500+Math.random()*2000);
}
function now(){return new Date().toLocaleTimeString('ru',{hour:'2-digit',minute:'2-digit'});}
function simReply(chatId){
  const chat=CHATS_D.find(c=>c.id===chatId);
  if(!chat)return;
  clearTyping();
  const txt=REPLY_POOL[Math.floor(Math.random()*REPLY_POOL.length)];
  const msgs=MSGS_D[chatId];
  const m={id:msgs.length+1,txt,out:false,time:now()};
  msgs.push(m);
  const area=document.getElementById('msgsArea');
  if(area){
    const wrap=document.createElement('div');
    wrap.innerHTML=renderMsg(m,chatId);
    area.appendChild(wrap.firstElementChild);
    area.scrollTop=area.scrollHeight;
  }
  chat.prev=txt;chat.time='сейчас';
}
let typingEl=null;
function showTypingIndicator(){
  const area=document.getElementById('msgsArea');
  if(!area||typingEl)return;
  typingEl=document.createElement('div');
  typingEl.className='mw in';
  typingEl.id='typingEl';
  typingEl.innerHTML=`<div class="typing-bbl"><div class="td"></div><div class="td"></div><div class="td"></div></div>`;
  area.appendChild(typingEl);
  area.scrollTop=area.scrollHeight;
  setTimeout(clearTyping,3000);
}
function clearTyping(){if(typingEl){typingEl.remove();typingEl=null;}}

// ── INPUT ──
function renderInput(){
  document.getElementById('inputStrip').innerHTML=`
    <div class="irow">
      <button class="att-btn" onclick="openAttach()">📎</button>
      <div class="ibox">
        <textarea class="itxt" id="msgTxt" placeholder="Написать сообщение..." rows="1"
          onkeydown="handleKey(event)" oninput="autoH(this)"></textarea>
        <button class="iem" onclick="toggleEmoji()">😊</button>
      </div>
      <button class="sbtn" id="sbtn" onclick="doSend()">
        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><line x1="22" y1="2" x2="11" y2="13"/><polygon points="22 2 15 22 11 13 2 9 22 2"/></svg>
      </button>
    </div>`;
}
function handleKey(e){if(e.key==='Enter'&&!e.shiftKey){e.preventDefault();doSend();}}
function autoH(el){el.style.height='auto';el.style.height=Math.min(el.scrollHeight,120)+'px';}
function doSend(){
  if(!S.currentChat)return;
  const inp=document.getElementById('msgTxt');
  const txt=inp?.value.trim();
  if(!txt)return;
  inp.value='';inp.style.height='auto';
  addMsg(txt,S.currentChat);
}
function setReply(mid,cid){
  const msgs=MSGS_D[parseInt(cid)];
  const m=msgs&&msgs.find(x=>x.id===mid);
  if(!m)return;
  const chat=CHATS_D.find(c=>c.id===parseInt(cid));
  S.replyTo={nm:m.out?'Вы':(chat?.name||''),tx:m.txt||'Голосовое'};
  const strip=document.getElementById('inputStrip');
  let rb=document.getElementById('rplyBarEl');
  if(!rb){
    rb=document.createElement('div');
    rb.id='rplyBarEl';
    rb.className='rply-bar';
    strip.insertBefore(rb,strip.firstChild);
  }
  rb.innerHTML=`<span style="color:var(--acc);font-size:18px">↩</span>
    <div style="flex:1;min-width:0"><div class="rply-nm">${S.replyTo.nm}</div><div class="rply-pv">${S.replyTo.tx}</div></div>
    <button class="crply" onclick="cancelReply()">✕</button>`;
}
function cancelReply(){S.replyTo=null;const rb=document.getElementById('rplyBarEl');if(rb)rb.remove();}

// ── CONTEXT MENU ──
function showCtx(e,el){
  closeAll();
  const mid=parseInt(el.dataset.mid),cid=parseInt(el.dataset.cid);
  const isOut=el.classList.contains('out');
  const menu=document.createElement('div');
  menu.className='ctx';
  menu.id='ctxMenu';
  menu.innerHTML=`
    <div class="ctx-i" onclick="setReply(${mid},${cid});closeAll()"><span>↩</span> Ответить</div>
    <div class="ctx-i" onclick="copyMsg(${mid},${cid});closeAll()"><span>📋</span> Копировать</div>
    <div class="ctx-i" onclick="closeAll();toast('↪','Переслано','Выберите чат')"><span>↪</span> Переслать</div>
    <div class="ctx-i" onclick="pinMsg(${mid},${cid});closeAll()"><span>📌</span> Закрепить</div>
    ${isOut?`<div class="ctx-i" onclick="closeAll();toast('✏️','Редактирование','Доступно в Premium')"><span>✏️</span> Изменить</div>`:''}
    <div class="ctx-i" onclick="selectMsg(${mid},${cid});closeAll()"><span>☑️</span> Выбрать</div>
    <div class="ctx-i dng" onclick="delMsg(${mid},${cid});closeAll()"><span>🗑️</span> Удалить</div>`;
  document.body.appendChild(menu);
  if(e){menu.style.left=Math.min(e.clientX,window.innerWidth-220)+'px';menu.style.top=Math.min(e.clientY,window.innerHeight-280)+'px';}
  else{menu.style.left='50%';menu.style.top='40%';menu.style.transform='translate(-50%,-50%)';}
  setTimeout(()=>document.addEventListener('click',closeAll,{once:true}),50);
}
function closeAll(){
  ['ctxMenu','rxnPickerEl','emojiPickerEl'].forEach(id=>{
    const el=document.getElementById(id);if(el)el.remove();
  });
  emojiOpen=false;
}
function copyMsg(mid,cid){const m=MSGS_D[cid]?.find(x=>x.id===mid);if(m?.txt)navigator.clipboard?.writeText(m.txt);toast('📋','Скопировано','');}
function pinMsg(mid,cid){const m=MSGS_D[cid]?.find(x=>x.id===mid);if(m?.txt){const pb=document.getElementById('pinnedStrip');pb.classList.remove('hidden');document.getElementById('pinText').textContent='📌 '+m.txt;}toast('📌','Закреплено','');}
function selectMsg(mid){const el=document.querySelector(`[data-mid="${mid}"]`);if(el)el.classList.toggle('selected');}
function delMsg(mid,cid){if(!MSGS_D[cid])return;MSGS_D[cid]=MSGS_D[cid].filter(x=>x.id!==mid);renderMsgs(cid);}

// ── REACTIONS ──
let rxnTarget={};
function showRxnPicker(e,el){
  closeAll();
  rxnTarget={mid:parseInt(el.dataset.mid),cid:parseInt(el.dataset.cid)};
  const p=document.createElement('div');
  p.className='rxn-picker';p.id='rxnPickerEl';
  p.innerHTML=['❤️','😂','🔥','👍','😢','🎉','🤩','💯','😍','🔥','👏','⭐'].map(r=>`<span class="rxn-o" onclick="addRxn('${r}',${rxnTarget.mid},${rxnTarget.cid})">${r}</span>`).join('');
  document.body.appendChild(p);
  p.style.left=Math.min(e.clientX-100,window.innerWidth-260)+'px';
  p.style.top=(e.clientY-70)+'px';
  setTimeout(()=>document.addEventListener('click',closeAll,{once:true}),50);
}
function addRxn(em,mid,cid){
  closeAll();
  const msgs=MSGS_D[parseInt(cid)];
  const m=msgs&&msgs.find(x=>x.id===mid);
  if(!m)return;
  if(!m.rxns)m.rxns={};
  m.rxns[em]=(m.rxns[em]||0)+1;
  renderMsgs(parseInt(cid));
  floatStar(em);
}

// ── EMOJI PICKER ──
function toggleEmoji(){
  if(emojiOpen){closeAll();return;}
  emojiOpen=true;
  const p=document.createElement('div');
  p.className='em-picker';p.id='emojiPickerEl';
  p.innerHTML=EMOJIS.map(e=>`<div class="em" onclick="insertEm('${e}')">${e}</div>`).join('');
  p.style.bottom='70px';p.style.left='8px';
  document.body.appendChild(p);
  setTimeout(()=>document.addEventListener('click',e=>{if(!p.contains(e.target)){closeAll();}},{once:true}),50);
}
function insertEm(e){const inp=document.getElementById('msgTxt');if(inp){inp.value+=e;inp.focus();}closeAll();}

// ── VOICE ──
function playVoice(btn){
  const playing=btn.textContent==='⏸';
  document.querySelectorAll('.pbtn').forEach(b=>b.textContent='▶');
  document.querySelectorAll('.wvb').forEach(b=>b.classList.remove('on'));
  if(!playing){
    btn.textContent='⏸';
    const bars=btn.parentElement.querySelectorAll('.wvb');
    let i=0;const iv=setInterval(()=>{
      if(i>0)bars[i-1]?.classList.remove('on');
      if(i>=bars.length){clearInterval(iv);btn.textContent='▶';return;}
      bars[i]?.classList.add('on');i++;
    },90);
  }
}

// ── ATTACH ──
function openAttach(){
  const opts=[['📷','Камера'],['🖼️','Галерея'],['📄','Файл'],['📍','Локация'],['🎵','Музыка'],['👤','Контакт'],['⏰','Отложить'],['🎥','Видео'],['💊','GIF'],['🗳️','Опрос']];
  showSheet('📎 Прикрепить',`<div style="display:grid;grid-template-columns:repeat(4,1fr);gap:8px;padding:16px">
    ${opts.map(([e,n])=>`<div onclick="closeSheet();toast('${e}','${n}','')" style="display:flex;flex-direction:column;align-items:center;gap:8px;padding:16px 8px;background:var(--bg3);border-radius:16px;cursor:pointer;transition:all .2s">
      <div style="font-size:30px">${e}</div><div style="font-size:11px;color:var(--txt2)">${n}</div>
    </div>`).join('')}
  </div>`);
}

// ── CHAT PROFILE ──
function openChatProfile(id){
  const chat=CHATS_D.find(c=>c.id===id);
  if(!chat)return;
  const myG=S.unlockedGifts.filter(g=>g._sentTo===id).slice(0,5);
  showSheet(chat.name,`
    <div style="display:flex;flex-direction:column;align-items:center;gap:12px;padding:20px">
      <div style="width:90px;height:90px;border-radius:50%;background:${chatBg(id)};display:flex;align-items:center;justify-content:center;font-size:44px;border:3px solid var(--bdr)">${chat.av}</div>
      <div style="font-size:22px;font-weight:900">${chat.name}</div>
      <div style="font-size:14px;color:var(--txt2)">@${chat.name.replace(/[^a-zA-Zа-яА-Я]/g,'').toLowerCase()}_himi</div>
      <div style="display:flex;align-items:center;gap:6px;font-size:13px"><div style="width:9px;height:9px;border-radius:50%;background:${chat.status==='online'?'var(--green)':'var(--txt3)'}"></div>${chat.status==='online'?'в сети':'не в сети'}</div>
      <div style="display:flex;gap:10px;width:100%;max-width:280px">
        <button class="btn-main" style="font-size:14px" onclick="closeSheet()">💬 Написать</button>
        <button class="btn-ghost" style="font-size:14px" onclick="closeSheet();openGiftSend(${id})">🎁 Подарок</button>
      </div>
    </div>
    <div style="padding:0 16px 16px">
      <div style="font-size:14px;font-weight:800;color:var(--gold);margin-bottom:10px">Подарки</div>
      <div style="display:flex;gap:10px;overflow-x:auto">
        ${myG.length?myG.map(g=>`<div style="width:64px;height:64px;border-radius:16px;background:var(--bg3);display:flex;align-items:center;justify-content:center;font-size:34px;flex-shrink:0">${g.em}</div>`).join(''):'<div style="color:var(--txt3);font-size:13px">Нет подарков</div>'}
      </div>
    </div>`);
}

// ── CHAT MENU ──
function chatMenu(id){
  showSheet('Чат',`<div class="sett-sect">
    <div class="sett-row" onclick="closeSheet();toast('🔕','Звук','Отключён')"><div class="si" style="background:var(--bg4)">🔕</div><div class="si-info"><div class="si-title">Отключить звук</div></div></div>
    <div class="sett-row" onclick="closeSheet();toast('📌','Закреплён','Чат закреплён')"><div class="si" style="background:var(--bg4)">📌</div><div class="si-info"><div class="si-title">Закрепить чат</div></div></div>
    <div class="sett-row" onclick="closeSheet();clearHistory(${id})"><div class="si" style="background:var(--red)">🗑️</div><div class="si-info"><div class="si-title" style="color:var(--red)">Очистить историю</div></div></div>
  </div>`);
}
function clearHistory(id){if(MSGS_D[id])MSGS_D[id]=[];renderMsgs(id);toast('🗑️','Удалено','История очищена');}

// ── STORE (GIFTS) ──
let currentCat='Все', currentPage=0;
const PAGE_SIZE=30;

function openStore(){
  const giftsHTML=renderGiftPage(0,'Все');
  showSheet('🛍️ Himi Store',`
    <div style="padding:8px 16px 4px;display:flex;align-items:center;gap:8px;border-bottom:1px solid var(--bdr);flex-shrink:0">
      <span style="font-size:22px">🪙</span>
      <span style="font-weight:900;color:var(--gold);font-size:18px">${S.coins}</span>
      <span style="color:var(--txt2);font-size:13px">монет</span>
      <button onclick="openCoins()" style="margin-left:auto;background:var(--gold);border:none;border-radius:12px;padding:7px 16px;font-family:inherit;font-weight:900;font-size:13px;cursor:pointer;color:#000">+ Пополнить</button>
    </div>
    <div style="display:flex;gap:6px;padding:10px 14px;overflow-x:auto;scrollbar-width:none;flex-shrink:0" id="catTabs">
      ${GIFT_CATS.map(c=>`<button onclick="switchGiftCat('${c}')" class="ftab ${c==='Все'?'on':''}" style="font-size:12px">${c}</button>`).join('')}
    </div>
    <div id="giftGrid" style="display:grid;grid-template-columns:repeat(3,1fr);gap:10px;padding:8px 14px;overflow-y:auto;max-height:60vh">
      ${giftsHTML}
    </div>
    <button onclick="loadMoreGifts()" id="loadMoreBtn" style="margin:8px 16px;padding:12px;background:var(--bg3);border:none;border-radius:14px;color:var(--acc);font-family:inherit;font-size:14px;font-weight:700;cursor:pointer;width:calc(100% - 32px)">Загрузить ещё (${ALL_GIFTS.length - PAGE_SIZE}+)</button>`,
  true);
}
function renderGiftPage(page,cat){
  const gifts=cat==='Все'?ALL_GIFTS:ALL_GIFTS.filter(g=>g.cat===cat);
  const slice=gifts.slice(page*PAGE_SIZE,(page+1)*PAGE_SIZE);
  return slice.map(g=>`
    <div class="gitem" onclick="buyGift(${g.id})">
      ${g.limited?`<div class="gi-lim">LTD</div>`:''}
      ${g.rarity==='legendary'&&!g.limited?`<div class="gi-new">NEW</div>`:''}
      <span class="gi-em">${g.em}</span>
      <div class="gi-name">${g.name}</div>
      <div class="gi-ed">${g.edition.toLocaleString()} шт.</div>
      <div class="gi-price">${S.adminUnlocked?'<span style="color:var(--green)">FREE</span>':'🪙 '+g.price}</div>
    </div>`).join('');
}
function switchGiftCat(cat){
  currentCat=cat;currentPage=0;
  document.querySelectorAll('#catTabs .ftab').forEach(b=>{b.classList.toggle('on',b.textContent.trim()===cat);});
  const grid=document.getElementById('giftGrid');
  if(grid)grid.innerHTML=renderGiftPage(0,cat);
  const btn=document.getElementById('loadMoreBtn');
  const total=(cat==='Все'?ALL_GIFTS:ALL_GIFTS.filter(g=>g.cat===cat)).length;
  if(btn)btn.textContent=`Загрузить ещё (${Math.max(0,total-PAGE_SIZE)}+)`;
}
function loadMoreGifts(){
  currentPage++;
  const gifts=currentCat==='Все'?ALL_GIFTS:ALL_GIFTS.filter(g=>g.cat===currentCat);
  const slice=gifts.slice(currentPage*PAGE_SIZE,(currentPage+1)*PAGE_SIZE);
  if(!slice.length){toast('ℹ️','Всё загружено','Это все подарки в категории');return;}
  const grid=document.getElementById('giftGrid');
  if(grid){
    const div=document.createElement('div');
    div.style.cssText='display:contents';
    div.innerHTML=slice.map(g=>`
      <div class="gitem" onclick="buyGift(${g.id})" style="animation:min .3s ease both">
        ${g.limited?`<div class="gi-lim">LTD</div>`:''}
        <span class="gi-em">${g.em}</span>
        <div class="gi-name">${g.name}</div>
        <div class="gi-ed">${g.edition.toLocaleString()} шт.</div>
        <div class="gi-price">${S.adminUnlocked?'<span style="color:var(--green)">FREE</span>':'🪙 '+g.price}</div>
      </div>`).join('');
    grid.appendChild(div);
  }
}
function buyGift(id){
  const g=ALL_GIFTS.find(x=>x.id===id);
  if(!g)return;
  if(!S.adminUnlocked&&S.coins<g.price){toast('⚠️','Не хватает монет',`Нужно ${g.price} монет`);return;}
  closeSheet();
  showGiftConfirm(g,S.currentChat||1);
}
function showGiftConfirm(g,toId){
  const toChat=CHATS_D.find(c=>c.id===toId);
  showSheet('🎁 Отправить подарок',`
    <div class="gsend-wrap">
      <div class="gsend-icon">${g.em}</div>
      <div class="gsend-name">${g.name}</div>
      <div class="gsend-to">Для: ${toChat?.name||'друга'}</div>
      <div class="${S.adminUnlocked?'gsend-free':'gsend-cost'}">${S.adminUnlocked?'🎁 БЕСПЛАТНО (Ключ активирован)':'🪙 '+g.price+' монет'}</div>
      <button class="gsend-btn" onclick="confirmSendGift(${g.id},${toId})">Отправить подарок 🎁</button>
    </div>`);
}
function confirmSendGift(gid,toId){
  const g=ALL_GIFTS.find(x=>x.id===gid);
  if(!g)return;
  if(!S.adminUnlocked){
    if(S.coins<g.price){toast('⚠️','Не хватает монет','');return;}
    S.coins-=g.price;
  }
  closeSheet();
  g._sentTo=toId;
  S.unlockedGifts.push({...g,_sentTo:toId});
  // Send as message
  if(S.currentChat){
    if(!MSGS_D[S.currentChat])MSGS_D[S.currentChat]=[];
    const m={id:Date.now(),txt:`🎁 Отправил подарок: ${g.em} ${g.name}`,out:true,time:now(),status:'✓'};
    MSGS_D[S.currentChat].push(m);
    const area=document.getElementById('msgsArea');
    if(area){const wrap=document.createElement('div');wrap.innerHTML=renderMsg(m,S.currentChat);area.appendChild(wrap.firstElementChild);area.scrollTop=area.scrollHeight;}
  }
  // Star burst
  for(let i=0;i<10;i++)setTimeout(()=>floatStar(g.em),i*120);
  toast(g.em,`Подарок "${g.name}" отправлен!`,S.adminUnlocked?'Бесплатно! 🎉':`-${g.price} монет`);
}

// Gift card viewer
function showGiftCard(id){
  const g=S.unlockedGifts.find(x=>x.id===id)||ALL_GIFTS.find(x=>x.id===id);
  if(!g)return;
  const pg=document.getElementById('pgGiftCard');
  pg.classList.remove('hidden');pg.classList.add('active');
  document.getElementById('giftCardBody').innerHTML=`
    <div class="gc-card">
      <div class="gc-icon-wrap">${g.em}</div>
      <div class="gc-name">${g.name}</div>
      <div class="gc-from">Подарок от ${S.user.name}</div>
      <div class="gc-rows">
        <div class="gc-row"><strong>Владелец</strong><span class="gc-val">${S.user.handle}</span></div>
        <div class="gc-row"><strong>Выпуск</strong><span>1 из ${g.edition.toLocaleString()}</span></div>
        <div class="gc-row"><strong>Ценность</strong><span class="gc-val">${g.price} ⭐</span></div>
        <div class="gc-row"><strong>Редкость</strong><span style="color:${rarityColor(g.rarity)}">${rarityName(g.rarity)}</span></div>
      </div>
    </div>`;
}
function closeGiftCard(){document.getElementById('pgGiftCard').classList.add('hidden');}
function rarityColor(r){return{common:'var(--txt2)',rare:'#4fc3f7',epic:'var(--prem)',legendary:'var(--gold)'}[r]||'var(--txt)';}
function rarityName(r){return{common:'Обычный',rare:'Редкий',epic:'Эпический',legendary:'Легендарный'}[r]||r;}

// Gift send from chat
function openGiftSend(toId){
  const cats=GIFT_CATS.slice(1,7);
  const sample=ALL_GIFTS.slice(0,12);
  showSheet('🎁 Отправить подарок',`
    <div style="display:grid;grid-template-columns:repeat(4,1fr);gap:8px;padding:14px 16px">
      ${sample.map(g=>`<div onclick="closeSheet();showGiftConfirm(ALL_GIFTS.find(x=>x.id===${g.id}),${toId})" style="background:var(--bg3);border-radius:16px;padding:12px 6px;text-align:center;cursor:pointer;border:2px solid transparent;transition:all .2s">
        <div style="font-size:36px;margin-bottom:6px">${g.em}</div>
        <div style="font-size:11px;font-weight:700">${g.name}</div>
        <div style="font-size:11px;color:var(--gold);margin-top:4px">${S.adminUnlocked?'FREE':'🪙 '+g.price}</div>
      </div>`).join('')}
    </div>
    <button onclick="closeSheet();openStore()" style="margin:0 16px 16px;padding:14px;background:var(--acc);border:none;border-radius:14px;color:#000;font-family:inherit;font-size:15px;font-weight:900;cursor:pointer;width:calc(100% - 32px)">Смотреть все 15,000+ подарков</button>`);
}

// ── ADMIN KEY ──
function openKeyPanel(){
  closeSheet();
  showSheet('🔑 Ввести ключ',`
    <div class="key-panel">
      <div class="kp-title">⭐ Активация привилегий</div>
      <div class="kp-desc">Введите секретный ключ для получения:<br>• Неограниченные подарки бесплатно<br>• Добавление любого числа звёзд<br>• Разблокировка всех функций</div>
      <input class="kinp" id="keyInp" type="text" placeholder="Введите ключ...">
      <button class="kbtn" onclick="activateKey()">Активировать ⭐</button>
      <div id="keyRes"></div>
      <div class="kbal">
        <div class="kbal-lbl">⭐ Текущий баланс</div>
        <div class="kbal-stars" id="kbalStars">${S.stars} звёзд</div>
        <div class="kbal-coins">🪙 ${S.coins} монет</div>
      </div>
    </div>`);
}
function activateKey(){
  const key=document.getElementById('keyInp')?.value.trim();
  const res=document.getElementById('keyRes');
  if(!res)return;
  if(key===ADMIN_KEY){
    S.adminUnlocked=true;
    res.className='kres ok';
    res.textContent='✅ Ключ принят! Выберите награду:';
    // Show reward options
    const panel=document.querySelector('.key-panel');
    if(panel){
      panel.insertAdjacentHTML('beforeend',`
        <div class="rew-opts" id="rewOpts">
          <div class="rew-opt" onclick="rewardGifts()">
            <div class="ro-icon">🎁</div>
            <div class="ro-info"><h4>Бесконечные подарки</h4><p>Дарить ЛЮБЫЕ подарки БЕСПЛАТНО навсегда</p></div>
          </div>
          <div class="rew-opt" onclick="showStarInput()">
            <div class="ro-icon">⭐</div>
            <div class="ro-info"><h4>Добавить звёзды</h4><p>Введите любое число звёзд</p></div>
          </div>
          <div class="rew-opt" onclick="rewardBoth()">
            <div class="ro-icon">💎</div>
            <div class="ro-info"><h4>Всё и сразу!</h4><p>Подарки + 99,999 звёзд + Premium</p></div>
          </div>
        </div>`);
    }
    for(let i=0;i<8;i++)setTimeout(()=>floatStar('⭐'),i*130);
    document.getElementById('keyInp').value='';
  } else {
    res.className='kres fail';
    res.textContent='❌ Неверный ключ';
    document.getElementById('keyInp').style.animation='shake .4s ease';
  }
}
function rewardGifts(){
  S.adminUnlocked=true;
  closeSheet();
  toast('🎁','Подарки разблокированы!','Теперь все подарки — БЕСПЛАТНО! 🎉');
  for(let i=0;i<12;i++)setTimeout(()=>floatStar(['🎁','🎊','🎉','⭐','💎','🔥'][i%6]),i*100);
}
function showStarInput(){
  const rewOpts=document.getElementById('rewOpts');
  if(rewOpts)rewOpts.innerHTML=`
    <div class="kp-desc" style="margin-top:0">Введите количество звёзд:</div>
    <input type="number" class="star-inp" id="starInp" placeholder="например: 999999" min="1">
    <button class="kbtn" onclick="addStars()">Добавить ⭐</button>`;
}
function addStars(){
  const n=parseInt(document.getElementById('starInp')?.value)||1000;
  if(n<1||n>999999999){toast('⚠️','Ошибка','Введите число от 1 до 999,999,999');return;}
  S.stars+=n;
  document.getElementById('kbalStars').textContent=S.stars.toLocaleString()+' звёзд';
  closeSheet();
  toast('⭐','Звёзды добавлены!',`+${n.toLocaleString()} ⭐. Итого: ${S.stars.toLocaleString()}`);
  for(let i=0;i<15;i++)setTimeout(()=>floatStar('⭐'),i*80);
  if(S.currentTab==='profile')switchTab('profile');
}
function rewardBoth(){
  S.adminUnlocked=true;
  S.stars+=99999;
  S.coins+=99999;
  S.premium=true;
  closeSheet();
  toast('💎','ВСЁ РАЗБЛОКИРОВАНО!','99,999 ⭐ + 99,999 🪙 + Premium! 🎊');
  for(let i=0;i<20;i++)setTimeout(()=>floatStar(['⭐','💎','🎁','👑','🔥','🎊'][i%6]),i*80);
  if(S.currentTab==='profile')switchTab('profile');
}

// ── PREMIUM ──
function openPremium(){
  showSheet('👑 Himi Premium',`
    <div class="prem-ban">
      <h2>Himi Premium ✨</h2>
      <p>Откройте все возможности мессенджера</p>
    </div>
    <div class="prem-feats">
      <div class="pf"><div class="pf-ic">🎨</div><div class="pf-tx">Эксклюзивные анимированные темы</div></div>
      <div class="pf"><div class="pf-ic">⭐</div><div class="pf-tx">Двойные Himi Coins</div></div>
      <div class="pf"><div class="pf-ic">🎁</div><div class="pf-tx">Особые подарки и значки</div></div>
      <div class="pf"><div class="pf-ic">🚀</div><div class="pf-tx">Приоритетная поддержка</div></div>
      <div class="pf"><div class="pf-ic">💎</div><div class="pf-tx">Уникальный значок Premium</div></div>
      <div class="pf"><div class="pf-ic">🎵</div><div class="pf-tx">Himi Music в профиле</div></div>
      <div class="pf"><div class="pf-ic">👥</div><div class="pf-tx">Расширенные группы до 100к</div></div>
      <div class="pf"><div class="pf-ic">📊</div><div class="pf-tx">Статистика профиля</div></div>
    </div>
    <button class="prem-buy" onclick="${S.premium?'toast(\"✅\",\"Уже активна\",\"Premium уже включён!\")':S.adminUnlocked?'activatePremiumFree()':'purchasePremium()'}">
      ${S.premium?'✅ Premium активна':S.adminUnlocked?'🎁 Получить бесплатно (Ключ)':'👑 Получить Premium — 499 ₽/мес'}</button>`);
}
function purchasePremium(){
  if(S.coins<500){toast('⚠️','Мало монет','Нужно 500 монет или ключ');return;}
  S.premium=true;S.coins-=500;
  closeSheet();toast('👑','Premium активирована!','🎉 Поздравляем!');
  for(let i=0;i<10;i++)setTimeout(()=>floatStar('👑'),i*100);
}
function activatePremiumFree(){S.premium=true;closeSheet();toast('👑','Premium активирована!','Бесплатно с вашим ключом! 🎉');}

// ── COINS ──
function openCoins(){
  showSheet('🪙 Himi Coins',`
    <div style="padding:20px 16px 0">
      <div class="coins-big">${S.coins.toLocaleString()}</div>
      <div class="coins-sub" style="margin-bottom:16px">Ваш текущий баланс</div>
      <div style="display:flex;flex-direction:column;gap:10px">
        ${[[100,'🪙','59 ₽',''],[500,'🪙🪙','249 ₽','+50 бонус'],[1000,'💰','449 ₽','+150 бонус'],[5000,'💎','1999 ₽','+1000 бонус']].map(([amt,em,pr,bon])=>`
          <div class="cp" onclick="buyCoinPkg(${amt})">
            <div class="cp-em">${em}</div>
            <div class="cp-inf"><div class="cp-amt">${amt} монет</div>${bon?`<div class="cp-bon">🎁 ${bon}</div>`:''}</div>
            <div class="cp-pr">${pr}</div>
          </div>`).join('')}
      </div>
    </div>`);
}
function buyCoinPkg(amt){
  S.coins+=amt;closeSheet();
  toast('🪙','Монеты получены!',`+${amt} монет. Баланс: ${S.coins}`);
  for(let i=0;i<6;i++)setTimeout(()=>floatStar('🪙'),i*150);
}

// ── GAMES ──
function openGames(){
  const games=[['🏓','Пинг-Понг','2 игрока','1,243 онлайн'],['🚀','Космос','Стрелялка','892 онлайн'],['🎯','Дартс','Меткость','456 онлайн'],['🃏','Карты','Дурак','2,100 онлайн'],['⚽','Футбол','Пенальти','789 онлайн'],['🧩','Пазл','Головоломка','234 онлайн']];
  showSheet('🎮 Himi Games',`<div class="games-grid">${games.map(([ic,nm,ds,pl])=>`
    <div class="gmcard" onclick="closeSheet();toast('🎮','${nm}','Загрузка...')">
      <div class="gmc-ic">${ic}</div>
      <div class="gmc-nm">${nm}</div>
      <div class="gmc-desc">${ds}</div>
      <div class="gmc-pl">🟢 ${pl}</div>
    </div>`).join('')}</div>`);
}

// ── THEMES ──
function openThemes(){
  const themes=[
    {nm:'Тёмный (по умолч.)',bg:'#0d1117',ac:'#4fc3f7',cur:true},
    {nm:'Ночной синий',bg:'#050a14',ac:'#64b5f6'},
    {nm:'Тёмный зелёный',bg:'#0a1a10',ac:'#66bb6a'},
    {nm:'Тёмно-фиолетовый',bg:'#100a1a',ac:'#ab47bc'},
    {nm:'Угольный',bg:'#0a0a0a',ac:'#f44336'},
    {nm:'Тёмно-синий',bg:'#0a0f20',ac:'#40c4ff'},
  ];
  showSheet('🎨 Темы оформления',`<div class="th-list">${themes.map(t=>`
    <div class="th-item ${t.cur?'cur':''}" onclick="applyTheme('${t.bg}','${t.ac}','${t.nm}')">
      <div class="th-swatch" style="background:${t.bg};border:2px solid ${t.ac}"></div>
      <div><div class="th-nm" style="color:white">${t.nm}</div><div class="th-cl">${t.bg}</div></div>
      ${t.cur?'<div class="th-chk">✓</div>':''}
    </div>`).join('')}</div>`);
}
function applyTheme(bg,ac,nm){
  document.documentElement.style.setProperty('--bg',bg);
  document.documentElement.style.setProperty('--acc',ac);
  closeSheet();toast('🎨',`Тема: ${nm}`,'Применена!');
}

// ── STORY ──
function openStory(id){
  const s=STORIES_D.find(x=>x.id===id);
  if(!s)return;
  const e=['🌅','🌊','🌌','🎉','🔥','💫'];
  const tx=['Красивый день!','Новое приключение 🚀','Himi лучший! 💎','Всем добра! ❤️','Живи ярко! ✨','Мир прекрасен! 🌟'];
  const i=Math.floor(Math.random()*6);
  const ov=document.createElement('div');
  ov.style.cssText='position:fixed;inset:0;z-index:800;background:#000;display:flex;flex-direction:column;animation:min .2s ease';
  ov.innerHTML=`
    <div class="stv-prog"><div class="stv-pb"><div class="stv-pf" id="svFill"></div></div></div>
    <div class="stv-hdr">
      <div class="stv-av">${s.av}</div>
      <div class="stv-nm">${s.name}</div>
      <div class="stv-tm">сейчас</div>
      <div class="stv-close" onclick="this.closest('div[style]').remove()">✕</div>
    </div>
    <div style="flex:1;display:flex;align-items:center;justify-content:center;position:relative;overflow:hidden;background:linear-gradient(135deg,#1a0a2e,#0a1a3e)">
      <div style="position:absolute;font-size:140px;opacity:.15;filter:blur(6px)">${e[i]}</div>
      <div style="font-size:28px;font-weight:900;color:#fff;text-align:center;padding:20px;text-shadow:0 2px 20px rgba(0,0,0,.9);position:relative;z-index:1">${e[i]}<br>${tx[i]}</div>
    </div>`;
  document.body.appendChild(ov);
  s.viewed=true;
  requestAnimationFrame(()=>{
    const fill=document.getElementById('svFill');
    if(fill)fill.style.cssText='height:100%;background:#fff;width:100%;transition:width 5s linear';
  });
  setTimeout(()=>ov.remove(),5200);
}

// ── SHEET / OVERLAY ──
let sheetEl=null;
function showSheet(title,body,tall=false){
  closeSheet();
  const ov=document.createElement('div');
  ov.className='ov';ov.id='sheetOv';
  ov.innerHTML=`<div class="sheet" style="animation:slideUp .35s cubic-bezier(.34,1.56,.64,1) both${tall?';max-height:95vh':''}">
    <div class="shandle"></div>
    <div class="stitle"><span>${title}</span><button class="cbtn" onclick="closeSheet()">✕</button></div>
    ${body}
  </div>`;
  ov.addEventListener('click',e=>{if(e.target===ov)closeSheet();});
  document.getElementById('overlayRoot').appendChild(ov);
  sheetEl=ov;
}
function closeSheet(){
  if(sheetEl){sheetEl.style.opacity='0';sheetEl.style.transition='opacity .2s';setTimeout(()=>sheetEl?.remove(),200);sheetEl=null;}
}

// ── TOAST ──
function toast(icon,title,msg){
  const wrap=document.createElement('div');
  wrap.className='toast-wrap';
  wrap.innerHTML=`<div class="toast"><div class="t-icon">${icon}</div><div><div class="t-title">${title}</div>${msg?`<div class="t-msg">${msg}</div>`:''}</div></div>`;
  document.body.appendChild(wrap);
  setTimeout(()=>wrap.remove(),4700);
}

// ── STAR FLOAT ──
function floatStar(em){
  const el=document.createElement('div');
  el.className='sf';el.textContent=em;
  el.style.left=Math.random()*window.innerWidth*.8+50+'px';
  el.style.bottom=Math.random()*200+100+'px';
  document.body.appendChild(el);
  setTimeout(()=>el.remove(),1400);
}

// ── ANIMATIONS ──
function addSlideUpCSS(){
  if(document.getElementById('_anim'))return;
  const s=document.createElement('style');
  s.id='_anim';
  s.textContent=`
    @keyframes slideUp{from{opacity:0;transform:translateY(50px)}to{opacity:1;transform:none}}
    @keyframes shake{0%,100%{transform:translateX(0)}25%{transform:translateX(-8px)}75%{transform:translateX(8px)}}
    @keyframes min{from{opacity:0;transform:translateY(10px) scale(.96)}to{opacity:1;transform:none}}
    .anim-fade{animation:min .3s ease both}`;
  document.head.appendChild(s);
}

// ── INIT ──
addSlideUpCSS();
makeParticles('splashParts');
makeParticles('regParts');
console.log('🚀 Himi Messenger loaded');
console.log(`📦 Gifts: ${typeof ALL_GIFTS !== 'undefined' ? ALL_GIFTS.length : 0}`);
