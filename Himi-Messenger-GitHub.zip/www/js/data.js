const ADMIN_KEY = 'Himigyter1202040912050505';
const AVATARS = ['🙂','😎','🤩','🥳','😏','🤗','😇','🤓','🧐','😍','🥰','😜','🤠','🧙','🦸','🦹','🧝','🧜','🧚','👻','🐱','🐯','🦊','🐺','🦁','🐻','🐼','🐨','🦄','🐉'];
const EMOJIS = ['😊','😂','❤️','🔥','👍','🙌','🎉','🤩','😍','🥰','😎','🤔','💯','✨','🌟','💫','🎊','🎈','🚀','💪','😄','🥳','🤗','😏','🫡','🫶','❄️','🌺','🌸','🌻','⭐','🌈','🎯','🏆','💎','🎵','🎶','🎸','🎹','💝','🦋','🌊','⚡','👏','🙏'];
const STORIES_D = [
  {id:1,name:'Алина',av:'👩',viewed:false},
  {id:2,name:'Макс',av:'🧑',viewed:false},
  {id:3,name:'Катя',av:'👧',viewed:true},
  {id:4,name:'Дима',av:'🧒',viewed:false},
  {id:5,name:'Himi',av:'💫',viewed:false},
];
const CHATS_D = [
  {id:1,name:'Алина ✨',av:'👩',status:'online',prev:'Привет! 😊',time:'сейчас',unread:3,premium:true},
  {id:2,name:'Himi Store 🛍️',av:'🛍️',status:'bot',prev:'Ваш заказ готов!',time:'12:30',unread:1,isBot:true},
  {id:3,name:'Макс 🔥',av:'🧑',status:'away',prev:'Ок, пока!',time:'11:45',unread:0},
  {id:4,name:'Himi AI 🤖',av:'🤖',status:'online',prev:'Чем помочь?',time:'вчера',unread:0,isBot:true},
  {id:5,name:'Группа друзей 🎉',av:'👥',status:'online',prev:'Катя: Идём гулять?',time:'10:00',unread:7,isGroup:true},
  {id:6,name:'Himi Games 🎮',av:'🎮',status:'bot',prev:'Новая игра!',time:'вчера',unread:0,isBot:true},
  {id:7,name:'Дима 🏀',av:'🧒',status:'offline',prev:'До завтра',time:'вчера',unread:0},
  {id:8,name:'Катя 💜',av:'👧',status:'online',prev:'Смотри что нашла!',time:'пн',unread:0,premium:true},
  {id:9,name:'Избранное ⭐',av:'⭐',status:'bot',prev:'Сохранённые',time:'пн',unread:0},
  {id:10,name:'Стикеры',av:'😄',status:'bot',prev:'3D Emoji набор',time:'пн',unread:0,isBot:true},
];
const MSGS_D = {
  1:[
    {id:1,txt:'Привет! Как твои дела? 😊',out:false,time:'12:00'},
    {id:2,txt:'Только что купила Himi Premium! 💜',out:false,time:'12:01'},
    {id:3,txt:'Вау! Я тоже думаю взять 🤔',out:true,time:'12:02',status:'✓✓'},
    {id:4,type:'voice',dur:'0:23',out:false,time:'12:05'},
    {id:5,txt:'Завтра выходят Himi Games! 🎮',out:true,time:'12:10',status:'✓✓'},
    {id:6,txt:'Да! Жду не дождусь 🔥',out:false,time:'12:11',rxns:{'🔥':2,'🎉':3}},
    {id:7,txt:'У меня 2500 монет уже 😎',out:true,time:'12:15',status:'✓✓'},
    {id:8,txt:'Подари что-нибудь! 😂',out:false,time:'12:16',rxns:{'😂':4}},
  ],
  2:[
    {id:1,txt:'🎁 Добро пожаловать в Himi Store!',out:false,time:'10:00'},
    {id:2,txt:'Здесь можно купить подарки и темы',out:false,time:'10:00'},
    {id:3,txt:'Ваш заказ #1234 доставлен! ✅',out:false,time:'12:30'},
  ],
  3:[
    {id:1,txt:'Видел новый апдейт?',out:false,time:'11:30',rxns:{'🤩':1}},
    {id:2,txt:'Реакции на сообщения огонь 🔥',out:true,time:'11:35',status:'✓✓'},
    {id:3,txt:'Ок, пока!',out:false,time:'11:45'},
  ],
  4:[
    {id:1,txt:'Привет! Я Himi AI 🤖',out:false,time:'09:00'},
    {id:2,txt:'Помогу с любым вопросом!',out:false,time:'09:00'},
  ],
  5:[
    {id:1,txt:'Всем привет! 👋',out:false,sender:'Алина',time:'09:30'},
    {id:2,txt:'Привет! 😄',out:false,sender:'Дима',time:'09:31'},
    {id:3,txt:'Идём гулять? ☀️',out:false,sender:'Катя',time:'10:00',rxns:{'👍':3,'❤️':2}},
    {id:4,txt:'Я за! 🙌',out:true,time:'10:02',status:'✓✓'},
  ],
};
const CONTACTS_D = [
  {id:1,name:'Алина',av:'👩',status:'online',handle:'@alina_himi',premium:true},
  {id:2,name:'Макс',av:'🧑',status:'away',handle:'@max_fire'},
  {id:3,name:'Катя',av:'👧',status:'online',handle:'@katya_h',premium:true},
  {id:4,name:'Дима',av:'🧒',status:'offline',handle:'@dima_bball'},
  {id:5,name:'Артём',av:'🧔',status:'online',handle:'@artem_himi'},
  {id:6,name:'Даша',av:'👱‍♀️',status:'online',handle:'@dasha_ok'},
  {id:7,name:'Никита',av:'👦',status:'offline',handle:'@nikita_gamer'},
  {id:8,name:'Юля',av:'👩‍🦰',status:'online',handle:'@yulya_h'},
];
const REPLY_POOL = ['😊 Понял!','Ок!','Согласен 👍','Хорошо!','Ого, интересно!','Точно 🔥','Да-да!','Классно!','❤️','Отлично!','Вот именно!','Супер! 🎉','Крутяк!','Согласна 😊','Топ!'];
