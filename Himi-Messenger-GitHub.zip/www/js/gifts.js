// ══════════════════════════════════════════════
// HIMI GIFTS DATABASE — 15,000+ уникальных подарков
// ══════════════════════════════════════════════

const GIFT_CATS = ['Все','🌹 Цветы','🎁 Классика','💎 Премиум','🎮 Геймеры','🍕 Еда','🌍 Природа','🎵 Музыка','⚽ Спорт','✈️ Путешествия','🦁 Животные','🎨 Арт','💫 Космос','🎃 Праздники','💝 Любовь','🔥 Редкие','⭐ Легендарные'];

// Базовые подарки (отображаемые — 100+)
const BASE_GIFTS = [
  // ЦВЕТЫ
  {id:1,em:'🌹',name:'Роза',cat:'🌹 Цветы',edition:8000,price:40,rarity:'common'},
  {id:2,em:'💐',name:'Букет',cat:'🌹 Цветы',edition:5000,price:80,rarity:'common'},
  {id:3,em:'🌷',name:'Тюльпан',cat:'🌹 Цветы',edition:7000,price:35,rarity:'common'},
  {id:4,em:'🌸',name:'Сакура',cat:'🌹 Цветы',edition:3000,price:120,rarity:'rare'},
  {id:5,em:'🌺',name:'Гибискус',cat:'🌹 Цветы',edition:4000,price:90,rarity:'common'},
  {id:6,em:'🌻',name:'Подсолнух',cat:'🌹 Цветы',edition:6000,price:50,rarity:'common'},
  {id:7,em:'🌼',name:'Ромашка',cat:'🌹 Цветы',edition:9000,price:25,rarity:'common'},
  {id:8,em:'💮',name:'Белый цветок',cat:'🌹 Цветы',edition:2000,price:180,rarity:'rare'},
  {id:9,em:'🪷',name:'Лотос',cat:'🌹 Цветы',edition:1500,price:250,rarity:'epic'},
  {id:10,em:'🌾',name:'Колосья',cat:'🌹 Цветы',edition:5500,price:60,rarity:'common'},
  // КЛАССИКА
  {id:11,em:'🎁',name:'Подарок',cat:'🎁 Классика',edition:10000,price:30,rarity:'common'},
  {id:12,em:'🎀',name:'Бант',cat:'🎁 Классика',edition:8000,price:40,rarity:'common'},
  {id:13,em:'🎂',name:'Торт',cat:'🎁 Классика',edition:6000,price:80,rarity:'common'},
  {id:14,em:'🍰',name:'Кусочек торта',cat:'🎁 Классика',edition:7000,price:50,rarity:'common'},
  {id:15,em:'🧸',name:'Мишка',cat:'🎁 Классика',edition:5000,price:100,rarity:'common'},
  {id:16,em:'🎈',name:'Шарик',cat:'🎁 Классика',edition:9000,price:20,rarity:'common'},
  {id:17,em:'🎊',name:'Конфетти',cat:'🎁 Классика',edition:8000,price:30,rarity:'common'},
  {id:18,em:'🎉',name:'Праздник',cat:'🎁 Классика',edition:7000,price:45,rarity:'common'},
  {id:19,em:'🪅',name:'Пиньята',cat:'🎁 Классика',edition:3000,price:150,rarity:'rare'},
  {id:20,em:'🎋',name:'Бамбук',cat:'🎁 Классика',edition:4000,price:90,rarity:'common'},
  // ПРЕМИУМ
  {id:21,em:'💎',name:'Алмаз',cat:'💎 Премиум',edition:500,price:1000,rarity:'legendary',limited:true},
  {id:22,em:'👑',name:'Корона',cat:'💎 Премиум',edition:800,price:750,rarity:'legendary',limited:true},
  {id:23,em:'🏆',name:'Кубок',cat:'💎 Премиум',edition:1000,price:500,rarity:'epic'},
  {id:24,em:'🥇',name:'Золото',cat:'💎 Премиум',edition:1500,price:350,rarity:'epic'},
  {id:25,em:'💍',name:'Кольцо',cat:'💎 Премиум',edition:600,price:900,rarity:'legendary',limited:true},
  {id:26,em:'🪙',name:'Монета',cat:'💎 Премиум',edition:5000,price:100,rarity:'rare'},
  {id:27,em:'💰',name:'Мешок денег',cat:'💎 Премиум',edition:2000,price:300,rarity:'epic'},
  {id:28,em:'🎖️',name:'Медаль',cat:'💎 Премиум',edition:1200,price:400,rarity:'epic'},
  {id:29,em:'🔮',name:'Хрустальный шар',cat:'💎 Премиум',edition:700,price:800,rarity:'legendary',limited:true},
  {id:30,em:'⚜️',name:'Геральдика',cat:'💎 Премиум',edition:400,price:1200,rarity:'legendary',limited:true},
  // ГЕЙМЕРЫ
  {id:31,em:'🎮',name:'Геймпад',cat:'🎮 Геймеры',edition:5000,price:120,rarity:'rare'},
  {id:32,em:'🕹️',name:'Джойстик',cat:'🎮 Геймеры',edition:4000,price:150,rarity:'rare'},
  {id:33,em:'👾',name:'Монстр',cat:'🎮 Геймеры',edition:3000,price:200,rarity:'rare'},
  {id:34,em:'🎯',name:'Мишень',cat:'🎮 Геймеры',edition:6000,price:80,rarity:'common'},
  {id:35,em:'🃏',name:'Карта Джокер',cat:'🎮 Геймеры',edition:2000,price:350,rarity:'epic'},
  {id:36,em:'🎲',name:'Кубик',cat:'🎮 Геймеры',edition:7000,price:60,rarity:'common'},
  {id:37,em:'♟️',name:'Ферзь',cat:'🎮 Геймеры',edition:1500,price:450,rarity:'epic'},
  {id:38,em:'🀄',name:'Маджонг',cat:'🎮 Геймеры',edition:2500,price:280,rarity:'rare'},
  {id:39,em:'🎰',name:'Слот-машина',cat:'🎮 Геймеры',edition:3500,price:220,rarity:'rare'},
  {id:40,em:'🧩',name:'Пазл',cat:'🎮 Геймеры',edition:5500,price:90,rarity:'common'},
  // ЕДА
  {id:41,em:'🍕',name:'Пицца',cat:'🍕 Еда',edition:8000,price:50,rarity:'common'},
  {id:42,em:'🍔',name:'Бургер',cat:'🍕 Еда',edition:7000,price:60,rarity:'common'},
  {id:43,em:'🍣',name:'Суши',cat:'🍕 Еда',edition:5000,price:100,rarity:'common'},
  {id:44,em:'🍜',name:'Рамен',cat:'🍕 Еда',edition:6000,price:80,rarity:'common'},
  {id:45,em:'🍦',name:'Мороженое',cat:'🍕 Еда',edition:9000,price:35,rarity:'common'},
  {id:46,em:'🧁',name:'Кексик',cat:'🍕 Еда',edition:8000,price:40,rarity:'common'},
  {id:47,em:'🍩',name:'Пончик',cat:'🍕 Еда',edition:7000,price:45,rarity:'common'},
  {id:48,em:'🍫',name:'Шоколад',cat:'🍕 Еда',edition:6000,price:70,rarity:'common'},
  {id:49,em:'🫐',name:'Черника',cat:'🍕 Еда',edition:5000,price:90,rarity:'common'},
  {id:50,em:'🍓',name:'Клубника',cat:'🍕 Еда',edition:8000,price:55,rarity:'common'},
  {id:51,em:'🥂',name:'Шампанское',cat:'🍕 Еда',edition:2000,price:300,rarity:'epic'},
  {id:52,em:'☕',name:'Кофе',cat:'🍕 Еда',edition:9000,price:30,rarity:'common'},
  {id:53,em:'🧋',name:'Боба',cat:'🍕 Еда',edition:6000,price:75,rarity:'common'},
  {id:54,em:'🍱',name:'Бенто',cat:'🍕 Еда',edition:4000,price:120,rarity:'rare'},
  {id:55,em:'🎂',name:'День рождения',cat:'🍕 Еда',edition:5000,price:95,rarity:'common'},
  // ПРИРОДА
  {id:56,em:'🌍',name:'Земля',cat:'🌍 Природа',edition:1000,price:500,rarity:'epic'},
  {id:57,em:'🌊',name:'Волна',cat:'🌍 Природа',edition:3000,price:180,rarity:'rare'},
  {id:58,em:'⛰️',name:'Горы',cat:'🌍 Природа',edition:2000,price:250,rarity:'rare'},
  {id:59,em:'🌋',name:'Вулкан',cat:'🌍 Природа',edition:1500,price:380,rarity:'epic'},
  {id:60,em:'🏝️',name:'Остров',cat:'🌍 Природа',edition:1200,price:450,rarity:'epic'},
  {id:61,em:'🌅',name:'Закат',cat:'🌍 Природа',edition:3500,price:160,rarity:'rare'},
  {id:62,em:'🌈',name:'Радуга',cat:'🌍 Природа',edition:2500,price:200,rarity:'rare'},
  {id:63,em:'❄️',name:'Снежинка',cat:'🌍 Природа',edition:5000,price:90,rarity:'common'},
  {id:64,em:'🌪️',name:'Торнадо',cat:'🌍 Природа',edition:800,price:700,rarity:'legendary',limited:true},
  {id:65,em:'🌠',name:'Падающая звезда',cat:'🌍 Природа',edition:1800,price:320,rarity:'epic'},
  // МУЗЫКА
  {id:66,em:'🎵',name:'Нота',cat:'🎵 Музыка',edition:8000,price:45,rarity:'common'},
  {id:67,em:'🎸',name:'Гитара',cat:'🎵 Музыка',edition:4000,price:130,rarity:'rare'},
  {id:68,em:'🎹',name:'Пианино',cat:'🎵 Музыка',edition:3000,price:200,rarity:'rare'},
  {id:69,em:'🎺',name:'Труба',cat:'🎵 Музыка',edition:3500,price:170,rarity:'rare'},
  {id:70,em:'🥁',name:'Барабаны',cat:'🎵 Музыка',edition:4500,price:140,rarity:'rare'},
  {id:71,em:'🎻',name:'Скрипка',cat:'🎵 Музыка',edition:2500,price:250,rarity:'epic'},
  {id:72,em:'🎷',name:'Саксофон',cat:'🎵 Музыка',edition:3000,price:210,rarity:'rare'},
  {id:73,em:'🪗',name:'Аккордеон',cat:'🎵 Музыка',edition:2000,price:280,rarity:'rare'},
  {id:74,em:'🎤',name:'Микрофон',cat:'🎵 Музыка',edition:5000,price:110,rarity:'rare'},
  {id:75,em:'🎧',name:'Наушники',cat:'🎵 Музыка',edition:6000,price:90,rarity:'common'},
  // СПОРТ
  {id:76,em:'⚽',name:'Мяч',cat:'⚽ Спорт',edition:8000,price:50,rarity:'common'},
  {id:77,em:'🏀',name:'Баскетбол',cat:'⚽ Спорт',edition:7000,price:60,rarity:'common'},
  {id:78,em:'🏈',name:'Американский футбол',cat:'⚽ Спорт',edition:5000,price:80,rarity:'common'},
  {id:79,em:'⚾',name:'Бейсбол',cat:'⚽ Спорт',edition:5500,price:75,rarity:'common'},
  {id:80,em:'🎾',name:'Теннис',cat:'⚽ Спорт',edition:6000,price:70,rarity:'common'},
  {id:81,em:'🏐',name:'Волейбол',cat:'⚽ Спорт',edition:6500,price:65,rarity:'common'},
  {id:82,em:'🥊',name:'Боксёрская перчатка',cat:'⚽ Спорт',edition:4000,price:130,rarity:'rare'},
  {id:83,em:'🏋️',name:'Штанга',cat:'⚽ Спорт',edition:3500,price:160,rarity:'rare'},
  {id:84,em:'🚴',name:'Велоспорт',cat:'⚽ Спорт',edition:4500,price:120,rarity:'rare'},
  {id:85,em:'🏊',name:'Плавание',cat:'⚽ Спорт',edition:5000,price:100,rarity:'common'},
  // ПУТЕШЕСТВИЯ
  {id:86,em:'✈️',name:'Самолёт',cat:'✈️ Путешествия',edition:3000,price:180,rarity:'rare'},
  {id:87,em:'🚀',name:'Ракета',cat:'✈️ Путешествия',edition:1000,price:500,rarity:'epic'},
  {id:88,em:'🛸',name:'НЛО',cat:'✈️ Путешествия',edition:800,price:700,rarity:'legendary',limited:true},
  {id:89,em:'🚢',name:'Корабль',cat:'✈️ Путешествия',edition:2000,price:280,rarity:'rare'},
  {id:90,em:'🏖️',name:'Пляж',cat:'✈️ Путешествия',edition:3500,price:150,rarity:'rare'},
  {id:91,em:'🗼',name:'Эйфелева башня',cat:'✈️ Путешествия',edition:2500,price:220,rarity:'rare'},
  {id:92,em:'🗽',name:'Статуя Свободы',cat:'✈️ Путешествия',edition:2000,price:280,rarity:'rare'},
  {id:93,em:'🏯',name:'Замок',cat:'✈️ Путешествия',edition:1500,price:380,rarity:'epic'},
  {id:94,em:'🌁',name:'Мост',cat:'✈️ Путешествия',edition:3000,price:190,rarity:'rare'},
  {id:95,em:'🧳',name:'Чемодан',cat:'✈️ Путешествия',edition:5000,price:110,rarity:'common'},
  // ЖИВОТНЫЕ
  {id:96,em:'🦁',name:'Лев',cat:'🦁 Животные',edition:1500,price:400,rarity:'epic'},
  {id:97,em:'🐯',name:'Тигр',cat:'🦁 Животные',edition:1500,price:400,rarity:'epic'},
  {id:98,em:'🦊',name:'Лиса',cat:'🦁 Животные',edition:3000,price:180,rarity:'rare'},
  {id:99,em:'🐺',name:'Волк',cat:'🦁 Животные',edition:2000,price:280,rarity:'rare'},
  {id:100,em:'🦋',name:'Бабочка',cat:'🦁 Животные',edition:4000,price:130,rarity:'rare'},
  {id:101,em:'🐉',name:'Дракон',cat:'🦁 Животные',edition:500,price:1500,rarity:'legendary',limited:true},
  {id:102,em:'🦄',name:'Единорог',cat:'🦁 Животные',edition:800,price:800,rarity:'legendary',limited:true},
  {id:103,em:'🐬',name:'Дельфин',cat:'🦁 Животные',edition:2500,price:220,rarity:'rare'},
  {id:104,em:'🦅',name:'Орёл',cat:'🦁 Животные',edition:1800,price:320,rarity:'epic'},
  {id:105,em:'🐼',name:'Панда',cat:'🦁 Животные',edition:2000,price:280,rarity:'rare'},
  // АРТ
  {id:106,em:'🎨',name:'Палитра',cat:'🎨 Арт',edition:4000,price:130,rarity:'rare'},
  {id:107,em:'🖼️',name:'Картина',cat:'🎨 Арт',edition:3000,price:200,rarity:'rare'},
  {id:108,em:'🎭',name:'Маски',cat:'🎨 Арт',edition:2500,price:240,rarity:'rare'},
  {id:109,em:'🎪',name:'Цирк',cat:'🎨 Арт',edition:3500,price:160,rarity:'rare'},
  {id:110,em:'🎬',name:'Кино',cat:'🎨 Арт',edition:4000,price:140,rarity:'rare'},
  {id:111,em:'📸',name:'Фото',cat:'🎨 Арт',edition:5000,price:100,rarity:'common'},
  {id:112,em:'✏️',name:'Карандаш',cat:'🎨 Арт',edition:7000,price:55,rarity:'common'},
  {id:113,em:'🖊️',name:'Ручка',cat:'🎨 Арт',edition:7000,price:50,rarity:'common'},
  {id:114,em:'📚',name:'Книги',cat:'🎨 Арт',edition:6000,price:80,rarity:'common'},
  {id:115,em:'🎭',name:'Театр',cat:'🎨 Арт',edition:2000,price:300,rarity:'epic'},
  // КОСМОС
  {id:116,em:'⭐',name:'Звезда',cat:'💫 Космос',edition:10000,price:20,rarity:'common'},
  {id:117,em:'🌟',name:'Блеск',cat:'💫 Космос',edition:8000,price:30,rarity:'common'},
  {id:118,em:'💫',name:'Кружащаяся звезда',cat:'💫 Космос',edition:6000,price:60,rarity:'common'},
  {id:119,em:'🌙',name:'Луна',cat:'💫 Космос',edition:4000,price:120,rarity:'rare'},
  {id:120,em:'☀️',name:'Солнце',cat:'💫 Космос',edition:3000,price:180,rarity:'rare'},
  {id:121,em:'🌌',name:'Галактика',cat:'💫 Космос',edition:800,price:800,rarity:'legendary',limited:true},
  {id:122,em:'🪐',name:'Сатурн',cat:'💫 Космос',edition:1200,price:480,rarity:'epic'},
  {id:123,em:'☄️',name:'Комета',cat:'💫 Космос',edition:1500,price:380,rarity:'epic'},
  {id:124,em:'🔭',name:'Телескоп',cat:'💫 Космос',edition:2500,price:250,rarity:'rare'},
  {id:125,em:'👨‍🚀',name:'Астронавт',cat:'💫 Космос',edition:2000,price:300,rarity:'epic'},
  // ПРАЗДНИКИ
  {id:126,em:'🎃',name:'Хэллоуин',cat:'🎃 Праздники',edition:3000,price:180,rarity:'rare',limited:true},
  {id:127,em:'🎄',name:'Ёлка',cat:'🎃 Праздники',edition:4000,price:140,rarity:'rare',limited:true},
  {id:128,em:'🎆',name:'Фейерверк',cat:'🎃 Праздники',edition:5000,price:100,rarity:'common'},
  {id:129,em:'🎇',name:'Бенгальский огонь',cat:'🎃 Праздники',edition:5000,price:95,rarity:'common'},
  {id:130,em:'🧨',name:'Петарда',cat:'🎃 Праздники',edition:4000,price:130,rarity:'rare'},
  {id:131,em:'🎑',name:'Любование луной',cat:'🎃 Праздники',edition:2000,price:280,rarity:'rare'},
  {id:132,em:'🎍',name:'Новый год',cat:'🎃 Праздники',edition:3000,price:200,rarity:'rare'},
  {id:133,em:'🪔',name:'Дивали',cat:'🎃 Праздники',edition:2500,price:230,rarity:'rare'},
  {id:134,em:'🕍',name:'Ханука',cat:'🎃 Праздники',edition:2000,price:280,rarity:'rare'},
  {id:135,em:'🎋',name:'Танабата',cat:'🎃 Праздники',edition:1500,price:350,rarity:'epic'},
  // ЛЮБОВЬ
  {id:136,em:'❤️',name:'Сердце',cat:'💝 Любовь',edition:12000,price:15,rarity:'common'},
  {id:137,em:'💕',name:'Два сердца',cat:'💝 Любовь',edition:10000,price:20,rarity:'common'},
  {id:138,em:'💖',name:'Искрящееся сердце',cat:'💝 Любовь',edition:8000,price:30,rarity:'common'},
  {id:139,em:'💝',name:'Сердце с лентой',cat:'💝 Любовь',edition:7000,price:45,rarity:'common'},
  {id:140,em:'💗',name:'Растущее сердце',cat:'💝 Любовь',edition:9000,price:25,rarity:'common'},
  {id:141,em:'💘',name:'Стрела купидона',cat:'💝 Любовь',edition:5000,price:90,rarity:'common'},
  {id:142,em:'💌',name:'Письмо любви',cat:'💝 Любовь',edition:4000,price:120,rarity:'rare'},
  {id:143,em:'🫀',name:'Живое сердце',cat:'💝 Любовь',edition:2000,price:280,rarity:'rare'},
  {id:144,em:'😍',name:'Влюблённый',cat:'💝 Любовь',edition:8000,price:40,rarity:'common'},
  {id:145,em:'🥰',name:'Обожание',cat:'💝 Любовь',edition:8000,price:40,rarity:'common'},
  // РЕДКИЕ
  {id:146,em:'🔱',name:'Трезубец',cat:'🔥 Редкие',edition:300,price:2000,rarity:'legendary',limited:true},
  {id:147,em:'⚡',name:'Молния',cat:'🔥 Редкие',edition:1000,price:500,rarity:'epic'},
  {id:148,em:'🌀',name:'Вихрь',cat:'🔥 Редкие',edition:800,price:700,rarity:'legendary',limited:true},
  {id:149,em:'🧿',name:'Глаз',cat:'🔥 Редкие',edition:1500,price:380,rarity:'epic'},
  {id:150,em:'☯️',name:'Инь-янь',cat:'🔥 Редкие',edition:1200,price:450,rarity:'epic'},
  {id:151,em:'🔴',name:'Красный шар',cat:'🔥 Редкие',edition:2000,price:300,rarity:'rare'},
  {id:152,em:'⬛',name:'Чёрный квадрат',cat:'🔥 Редкие',edition:100,price:5000,rarity:'legendary',limited:true},
  {id:153,em:'🌑',name:'Новая луна',cat:'🔥 Редкие',edition:600,price:900,rarity:'legendary',limited:true},
  {id:154,em:'🧬',name:'ДНК',cat:'🔥 Редкие',edition:700,price:800,rarity:'legendary',limited:true},
  {id:155,em:'⚗️',name:'Алхимия',cat:'🔥 Редкие',edition:400,price:1500,rarity:'legendary',limited:true},
  // ЛЕГЕНДАРНЫЕ
  {id:156,em:'🏅',name:'Золотая медаль',cat:'⭐ Легендарные',edition:200,price:8000,rarity:'legendary',limited:true},
  {id:157,em:'🎪',name:'Вечный цирк',cat:'⭐ Легендарные',edition:150,price:10000,rarity:'legendary',limited:true},
  {id:158,em:'🌈',name:'Радужный дракон',cat:'⭐ Легендарные',edition:100,price:15000,rarity:'legendary',limited:true},
  {id:159,em:'🦋',name:'Алмазная бабочка',cat:'⭐ Легендарные',edition:80,price:18000,rarity:'legendary',limited:true},
  {id:160,em:'🌌',name:'Вселенная',cat:'⭐ Легендарные',edition:50,price:25000,rarity:'legendary',limited:true},
];

// Генерация остальных 15000+ подарков программно
const EXTRA_EMOJIS = ['🍎','🍊','🍋','🍇','🍉','🍑','🥭','🍍','🥝','🍒','🫒','🥑','🌽','🥦','🥕','🧅','🧄','🫑','🥬','🍆','🫘','🌰','🍄','🐸','🐢','🦎','🐍','🦕','🦖','🐙','🦑','🦐','🦞','🦀','🐡','🐠','🐟','🐊','🦭','🐧','🦜','🦩','🦚','🦃','🦤','🦢','🕊️','🦆','🐓','🦅','🦉','🦇','🐝','🪱','🦟','🦗','🪲','🐞','🦋','🐛','🪳','🕷️','🦂','🐜','🪰','🦠','💐','🌷','🌹','🥀','🌺','🌸','🌼','🌻','🌞','🌝','🌛','🌜','🌚','🌕','🌖','🌗','🌘','🌑','🌒','🌓','🌔','🌙','🌟','⭐','🌠','🌌','☀️','🌤️','⛅','🌥️','☁️','🌦️','🌧️','⛈️','🌩️','🌨️','❄️','☃️','⛄','🌬️','💨','💧','💦','🌊','🔥','🌈','⚡','🌪️','🌫️','🌈','🌂','☂️','☔','⛱️'];

function generateGifts() {
  const all = [...BASE_GIFTS];
  const rarities = ['common','common','common','rare','rare','epic','legendary'];
  const cats = ['🎁 Классика','🌹 Цветы','🎮 Геймеры','🍕 Еда','🌍 Природа','🎵 Музыка'];
  let id = 200;
  // Generate additional gifts to reach 15000+
  for(let i = 0; i < 14840; i++) {
    const em = EXTRA_EMOJIS[i % EXTRA_EMOJIS.length];
    const rar = rarities[i % rarities.length];
    const cat = cats[i % cats.length];
    const priceMap = {common:Math.floor(Math.random()*80)+15, rare:Math.floor(Math.random()*200)+100, epic:Math.floor(Math.random()*500)+300, legendary:Math.floor(Math.random()*2000)+1000};
    all.push({
      id: id++,
      em,
      name: `${em} #${id}`,
      cat,
      edition: Math.floor(Math.random()*9000)+500,
      price: priceMap[rar],
      rarity: rar,
      limited: rar === 'legendary' && Math.random() > 0.7
    });
  }
  return all;
}

const ALL_GIFTS = generateGifts();
console.log(`✅ Загружено ${ALL_GIFTS.length} подарков`);
